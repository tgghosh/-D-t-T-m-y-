#### 𝄟✮͢🦋⃟≛⃝Dûßtø(Töñmöy)❥𝄟✮⃝♥️ MD WHATSAPP BOT
jarvis md is Multi Device whatsapp bot based on X-𝄟✮͢🦋⃟≛⃝Dûßtø(Töñmöy)❥𝄟✮⃝♥️


### SETUP 𝄟✮͢🦋⃟≛⃝Dûßtø(Töñmöy)❥𝄟✮⃝♥️

1. Scan the QR code
    <br>
<a href='https://jarvis.lokiser.xyz/' target="_blank"><img alt='SCAN QR' src='https://img.shields.io/badge/Scan_qr-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>

#### DEPLOY TO HEROKU 

1. If You don't have a account in Heroku. Create a account in heroku.
    <br>
<a href='https://signup.heroku.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=heroku&logoColor=white'/></a>

3. Now Deploy
    <br>
<a href='https://heroku.com/deploy?template=https://github.com/Loki-Xer/Jarvis-md' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Deploy-black?style=for-the-badge&logo=heroku&logoColor=white'/></a>


#### DEPLOY TO RAILWAY

1. If You don't have a account in railway. Create a account in railway.
    <br>
<a href='https://railway.app/login' target="_blank"><img alt='railway' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=railway&logoColor=white'/></a>

2. Now Deploy
    <br>
<a href='https://railway.app/template/gDYcSS?referralCode=wgSM5y' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=railway&logoColor=white'/></a>


#### THANKS TO
- [𝄟✮͢🦋⃟≛⃝Dûßtø(Töñmöy)❥𝄟✮⃝♥️](https://github.com/tgghosh) <br>
- [X-𝄟✮͢🦋⃟≛⃝Dûßtø(Töñmöy)❥𝄟✮⃝♥️](https://github.com/tgghosh) for [X-𝄟✮͢🦋⃟≛⃝Dûßtø(Töñmöy)❥𝄟✮⃝♥️](https://github.com/tgghosh)

#### 𝄟✮͢🦋⃟≛⃝Dûßtø(Töñmöy)❥𝄟✮⃝♥️ WhatsApp SUPPORT  

<a href="https://chat.whatsapp.com/G4jqF3z6gA3BJVoX8EppzE"><img alt="WhatsApp" src="https://img.shields.io/badge/-Whatsapp%20Channel-white?style=for-the-badge&logo=whatsapp&logoColor=black"/></a>
